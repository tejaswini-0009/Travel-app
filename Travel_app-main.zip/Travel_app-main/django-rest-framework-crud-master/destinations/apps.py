from django.apps import AppConfig


class DestinationConfig(AppConfig):
    name = 'destinations'
